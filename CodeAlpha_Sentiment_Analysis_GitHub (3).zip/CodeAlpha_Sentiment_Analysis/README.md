# CodeAlpha Sentiment Analysis

A beginner-friendly Python project classifying customer reviews as **Positive**, **Negative**, or **Neutral** using NLTK VADER.

## Features
- Loads `reviews.csv` if supplied, otherwise uses fictional sample reviews
- Cleans review text and calculates VADER compound sentiment scores
- Visualizes sentiment counts, percentages, review lengths, and frequent words
- Displays the strongest positive and negative reviews
- Exports analyzed reviews to `outputs/sentiment_analysis_results.csv`

## Run the project
1. Install Python and Jupyter.
2. Install dependencies:

   ```bash
   pip install -r requirements.txt
   ```

3. Open `Sentiment_Analysis.ipynb` in Jupyter Notebook/JupyterLab and run all cells from top to bottom. On first run, NLTK may need internet access to download the VADER lexicon.

## Use your own data
Place `reviews.csv` beside the notebook. It must have a column named `review` with one review per row. The included sample data is fictional and for demonstration only.

## Output
Charts and the results CSV are saved in the `outputs/` folder when the notebook runs.

## Limitation
VADER can misinterpret sarcasm, context, spelling variations, and domain-specific language. Sentiment labels are estimates, not ground truth.
